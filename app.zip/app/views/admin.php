<?php  require_once VIEW_ROOT.'/theme/header.php'; ?>
<?php  require_once VIEW_ROOT.'/theme/navbar.php'; ?>
<?php 
/* Eğer giriş yapılmamışsa URL olarak index sayfasına yönlendiriliyor. */
if(!isset($_SESSION["login"])):?>
<div class="row gutters mt-2 p-2">
	<div class="col col-2"></div>
	<div class="col col-8 mb-3">
		<div class="row gutters mt-3">
			<div class="col col-4"></div>
			<div class="col col-4">
				<div class="mb-5">
					<h4><strong>Yazar Girişi</strong></h4>
					<form method="POST" id="loginForm">
					<div class="form-item">
						<label>Kullanıcı Adı</label>
						<input type="text" name="getUsername" id="getUsername" class="small">
						<div class="desc">Yetki sahibi yazarın kullanıcı adını girin</div>
					</div>
					<div class="form-item">
						<label>Şifre</label>
						<input type="password" name="getPassword" id="getPassword" class="small">
						<div class="desc">Yetki sahibi yazarın şifresini girin</div>
					</div>
					<div class="form-item">
						<button class="small button">Giriş Yap</button>
					</div>
					</form>
					<div id="resultLogin"></div>
					<div class="desc">Yetkilendirmeyle ilgili herhangi bir sorunuz varsa veya müşteriniz ancak giriş kimlik bilgilerinizi almadıysanız, bize merhaba@siyahpapyon.com adresinden kısa bir e-posta gönderin ve hemen düzeltin.</div>
				</div>
			</div>
			<div class="col col-4"></div>
		</div>

	</div>
	<div class="col col-2"></div>
</div>
<?php else: ?>
	<div class="row gutters mt-2 p-2">
		<div class="col col-2"></div>
		<div class="col col-8 mb-3">

			<div class="row gutters">
				<div class="col col-8 p-2" style="border-right: 1px solid #F2F3F4;">
					<div class="p-1 mb-4">
						<h3><strong>Okuma Kartı Oluştur.</strong></h3>
						<p class="lead">Hoşgeldin <?php echo $_SESSION['getUserFullname']; ?>,<br>Kendine has düşüncelerinle özgün okuma kartları oluştur.</p>
					</div>

					<form method="post" action="<?php echo BASE_URL; ?>/admin" class="form" enctype="multipart/form-data">
						<div class="row gutters">
							<div class="col col-8">
								<div class="form-item">
									<label><h5><strong>-> Başlık</strong></h5></label>
									<input type="text" name="getBlogTitle" style="border:none;" placeholder="Yazı başlığı">
								</div>
							</div>
							<div class="col col-4">
								<div class="form-item">
									<label><h5><strong>-> Kategori Seç</strong></h5></label>
									<?php  foreach($listCategory as $category): ?>
										<label class="radio"><input type="radio" name="getBlogCategory" value="<?php echo $category['getCategoryID']; ?>"> <?php echo $category['getCategoryName']; ?></label>
									<?php endforeach; ?>
								</div>
							</div>
						</div>

						<div class="form-item mt-5 mb-5">
							<label><h5><strong>-> Yazının İçeriği</strong></h5></label>
							<textarea rows="6" class="content" name="getBlogContent" placeholder="Tüm içeriği bu alana girerek yazını tamamlayabilirsin"></textarea>
						</div>			    
						<div class="form-item mt-5 mb-5">
							<label><h5><strong>-> Resim</strong></h5></label>
							<input type="file" name="getBlogImages">
							<div class="desc">Önerilen görsel boyutu 564x797px, jpg veya png formatıdır.</div>
						</div>
						<div class="form-item mt-5 mb-5">
							<label><h5><strong>-> Resim Kaynak Açıklaması</strong></h5></label>
							<input type="text" name="getBlogImagesAbout" style="border:none;" placeholder="Kaynak hakkında...">
							<div class="desc">Kullandığın görselin kaynağını url olarak bir metin ile ifade et</div>
						</div>			    

						<div class="form-item">
							<input type="hidden" name="getBlogCreate">
							<button class="small button">Şimdi Paylaş</button>
						</div>

					</form>
				</div>
				<div class="col col-4 p-2">

					<?php  foreach($listBlog as $blog): ?>
						<div class="img-container">
							<img src="<?php echo $blog['getBlogImages']; ?>">
							<p class="topleft-d"><?php echo $blog['getCategoryName']; ?> </p>
							<h3 class="topleft"><?php echo $blog['getBlogTitle']; ?></h3>
							<p class="topleft-p"><?php echo strip_tags(substr($blog['getBlogContent'],0,119)); ?>...</p>
							<a href="<?php echo BASE_URL; ?>/b/<?php echo $blog['getBlogID']; ?>" class="small button topleft-b">Şimdi Oku -> <?php echo $blog['hit']; ?> kez okundu</a>
						</div>
						<div class="desc mb-4"><?php echo $blog['getBlogImagesAbout']; ?> </div>

					<?php endforeach; ?>           		

					<form method="post" id="addCategory" class="form">

						<div class="form-item">
							<label><h5><strong>-> Kategori İsmi</strong></h5></label>
							<input type="text" name="getCategoryName" id="getCategoryName" placeholder="Kategori belirle...">
							<div class="desc">Kullandığın görselin kaynağını url olarak bir metin ile ifade et. Kullandığın görselin </div>
						</div>

						<div class="form-item">
							<button type="submit" class="small button">Kategori Oluştur</button>
							<div class="desc" id="resultCategory"></div>
						</div>

					</form>
					<table>
						<thead>
							<tr>
								<th>Kategori Adı</th>
								<th>İşlem</th>
							</tr>
						</thead>
						<tbody>
							<?php  foreach($listCategory as $category): ?>
								<tr>
									<td><strong>-> <?php echo $category['getCategoryName']; ?></strong></td>
									<td><a href="#" data-component="dropdown" data-target="#<?php echo $category['getCategoryID']; ?>" style="font-weight: bold;text-decoration:none;">Sil</a></td>
								</tr>
								<div class="dropdown hide" id="<?php echo $category['getCategoryID']; ?>">
									<a href="" class="close show-sm"></a>
									<ul>
										<li><a href="<?php echo BASE_URL; ?>/d/<?php echo $category['getCategoryID']; ?>">Kategoriyi Sil</a></li>
										<li><a href="">Vazgeç</a></li>
									</ul>
								</div>
							<?php endforeach; ?>

						</tbody>
					</table>
					<div class="desc p-1" style="line-height: 18px;">Not: Eğer sileceğiniz kategoriye ait okuma kartı varsa; hem okuma kartları hem de kategori kalıcı olarak silinecektir.</div>

				</div>
			</div>

		</div>
		<div class="col col-2"></div>
	</div>   
<?php  endif; ?>
<?php require_once VIEW_ROOT.'/theme/footer.php'; ?>
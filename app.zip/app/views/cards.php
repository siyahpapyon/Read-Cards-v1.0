<?php  require_once VIEW_ROOT.'/theme/header.php'; ?>
<?php  require_once VIEW_ROOT.'/theme/navbar.php'; ?>
<?php 
/* Eğer giriş yapılmamışsa URL olarak index sayfasına yönlendiriliyor. */
if(!isset($_SESSION["login"])):
	header('Location:'.BASE_URL.'/admin');?>

	<?php else: ?>
		<div class="row gutters p-2">
			<div class="col col-2"></div>
			<div class="col col-8 mb-3">


				<div class="p-3 mb-4">
					<h3><strong>Okuma Kartların Listesi.</strong></h3>
					<p class="lead">Hoşgeldin <?php echo $_SESSION['getUserFullname']; ?>,<br>Fikir ve düşüncelerinle özgün okuma kartları oluştur.</p>
					<a href="<?php echo BASE_URL; ?>/admin" class="button small">Okuma Kartı Oluştur</a>
				</div>
				<div class="row gutters">
					<?php  if($listBlog->rowCount()): ?>
						<?php  foreach($listBlog as $blog): ?>
							<div class="col col-4 work-one" data-filter="<?php echo $blog['getBlogCategory']; ?>">
								<div class="img-container">
									<img src="<?php echo BASE_URL; ?>/<?php echo $blog['getBlogImages']; ?>">
									<p class="topleft-d"><?php echo $blog['getCategoryName']; ?> </p>
									<h3 class="topleft"><?php echo $blog['getBlogTitle']; ?></h3>
									<p class="topleft-p"><?php echo strip_tags(substr($blog['getBlogContent'],0,119)); ?>... <br><span>-> <?php echo $blog['hit']; ?> kez okundu</span></p>
									<a href="#" data-component="dropdown" data-target="#<?php echo $blog['getBlogID']; ?>" class="small button topleft-b">Seçenekler <span class="caret down"></span></a>
								</div>
								<div class="dropdown hide" id="<?php echo $blog['getBlogID']; ?>">
									<a href="" class="close show-sm"></a>
									<ul>
										<li><a href="<?php echo BASE_URL; ?>/b/<?php echo $blog['getBlogID']; ?>">Şimdi Oku</a></li>
										<li><a href="<?php echo BASE_URL; ?>/e/<?php echo $blog['getBlogID']; ?>">Düzenle</a></li>
										<ul>
											<li data-component="collapse">
												<a href="#d<?php echo $blog['getBlogID']; ?>" class="collapse-toggle">
													Kartı Sil
													<span class="caret down"></span>
												</a>
												<ul id="d<?php echo $blog['getBlogID']; ?>" class="collapse-box hide">
													<li><a href="<?php echo BASE_URL; ?>/dc/<?php echo $blog['getBlogID']; ?>">Şimdi Sil <br><span class="desc">Not: Bu kart kalıcı olarak silinecektir.</span></a></li>
												</ul>
											</li>
										</ul>
									</ul>
								</div>

								<div class="desc mb-4"><?php echo $blog['getBlogImagesAbout']; ?> </div>
							</div>
						<?php endforeach; ?>  
						<?php  else: ?>
							<div class="col col-4 mb-3 tex-center">
								<div class="ghost-card"></div>
							</div> 
							<div class="col col-4 mb-3">
								<div class="ghost-card"></div>
							</div>	
							<div class="col col-4 mb-3">
								<div class="ghost-card"></div>
							</div>									 
						<?php endif; ?>
					</div>

					<nav class="pagination">
						<ul>
							<li class="prev"><a href="<?php echo BASE_URL; ?>/cards/1">&larr;</a></li>
							<?php  for($i = $page - $forlimit; $i < $page + $forlimit + 1; $i++){?>
								<?php if($i > 0 && $i <= $pagesNumber): ?>
									<?php  if($i == $page):?>
										<li class="page-item active"><a class="page-link" href="<?php echo BASE_URL; ?>/cards/<?php echo $i; ?>"><?php echo $i; ?></a></li>
										<?php else: ?>
											<li class="page-item"><a class="page-link" href="<?php echo BASE_URL; ?>/cards/<?php echo $i; ?>"><?php echo $i; ?></a></li>
										<?php  endif; ?>
									<?php endif; ?>
								<?php  } ?>

								<?php if($page != $pagesNumber): ?>
									<li class="next"><a href="<?php echo BASE_URL; ?>/cards/<?php echo $pagesNumber; ?>">&rarr;</a></li>
								<?php endif; ?>
							</ul>
						</nav>					

					</div>
					<div class="col col-2"></div>
				</div>   
			<?php  endif; ?>
			<?php require_once VIEW_ROOT.'/theme/footer.php'; ?>
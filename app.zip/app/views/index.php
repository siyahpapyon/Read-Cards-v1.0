<?php  require_once VIEW_ROOT.'/theme/header.php'; ?>
<?php  require_once VIEW_ROOT.'/theme/navbar.php'; ?>
<div class="row gutters p-2">
	<div class="col col-2"></div>
	<div class="col col-8 mb-3">
<!--
Düşüncesini özgürce ifade edenler için küçük ve göze çarpmayan bir yardımcı olarak tasarladık. Read Cards temel olarak rutin görevleri minimumda tutmaya yardımcı olan bir araçtır. Sizin için anlaşılabilmek için yeri doldurulamaz bir araç haline gelebilir. Kesinlikle Read Cards'ı indirip keşfetmekten çekinmeyin ve bu yolculuğun sizi nereye götüreceğini görün.
-->
		<div class="row gutters">
			<?php  if($listBlog->rowCount()): ?>
				<?php foreach($listBlog as $blog): ?>
					<div class="col col-4 mb-3 work-one" data-filter="<?php echo $blog['getBlogCategory']; ?>">
						<div class="img-container">
							<img src="<?php echo BASE_URL; ?>/<?php echo $blog['getBlogImages']; ?>">
							<p class="topleft-d"><?php echo $blog['getCategoryName']; ?> </p>
							<h3 class="topleft"><?php echo $blog['getBlogTitle']; ?></h3>
							<p class="topleft-p"><?php echo strip_tags(substr($blog['getBlogContent'],0,119)); ?>...</p>
							<a href="<?php echo BASE_URL; ?>/b/<?php echo $blog['getBlogID']; ?>" class="small button topleft-b">Şimdi Oku -> <?php echo $blog['hit']; ?> kez okundu</a>
						</div>
					</div>
				<?php endforeach; ?>
				<?php  else: ?>
					<div class="col col-4 mb-3">
						<div class="ghost-card">
							<h4 style="color:#D0D3D4;margin-top:80px;">Henüz Okuma Kartı Oluşturulmadı!</h4>
							<p>Tek yapman gereken; özgün bir içerik üretmek ve okuma kartı oluşturmak</p>
							<?php if(isset($_SESSION['login'])): ?>
								<a href="<?php echo BASE_URL; ?>/admin" class="button small">Okuma Kartı Oluştur</a>
							<?php endif; ?>
						</div>
					</div>
					<div class="col col-4 mb-3 tex-center">
						<div class="ghost-card"></div>
					</div> 
					<div class="col col-4 mb-3">
						<div class="ghost-card"></div>
					</div>										 
				<?php endif; ?>	
			</div>

			<nav class="pagination">
				<ul>
					<li class="prev"><a href="<?php echo BASE_URL; ?>/c/1">&larr;</a></li>
					<?php  for($i = $page - $forlimit; $i < $page + $forlimit + 1; $i++){?>
						<?php if($i > 0 && $i <= $pagesNumber): ?>
							<?php  if($i == $page):?>
								<li class="page-item active"><a class="page-link" href="<?php echo BASE_URL; ?>/c/<?php echo $i; ?>"><?php echo $i; ?></a></li>
								<?php else: ?>
									<li class="page-item"><a class="page-link" href="<?php echo BASE_URL; ?>/c/<?php echo $i; ?>"><?php echo $i; ?></a></li>
								<?php  endif; ?>
							<?php endif; ?>
						<?php  } ?>

						<?php if($page != $pagesNumber): ?>
							<li class="next"><a href="<?php echo BASE_URL; ?>/c/<?php echo $pagesNumber; ?>">&rarr;</a></li>
						<?php endif; ?>
					</ul>
				</nav>


			</div>
			<div class="col col-2"></div>
		</div>   
		<?php require_once VIEW_ROOT.'/theme/footer.php'; ?>
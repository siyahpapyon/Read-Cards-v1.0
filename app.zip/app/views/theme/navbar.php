<?php session_start(); ?>
<header class="header-mobile show-sm">
	<section>
		<div class="brand">
			<a href="<?php echo BASE_URL; ?>/blog">Read Cards.</a>
		</div>
		<a href="#" id="nav-toggle" data-component="toggleme" data-target="#navigation-mobile"><i class="kube-menu"></i></a>
	</section>
	<nav id="navigation-mobile" class="navigation hide"><ul>
		<li><a href="<?php echo BASE_URL; ?>">Anasayfa</a></li>
		<!--<li><a href="#" class="selected" data-filter="*" id="filter-a">Tüm Kategori</a></li>-->
		<?php  foreach($listCategory as $category): ?>
			<li><a href="#" data-filter="<?php echo $category['getCategoryID']; ?>" id="filter-a"><?php echo $category['getCategoryName']; ?></a></li>
		<?php endforeach; ?>

		<?php if(!isset($_SESSION['login'])): ?>
			<li><a href="<?php echo BASE_URL; ?>/admin"> Giriş Yap</a></li>
			<?php else: ?>
				<li><a href="<?php echo BASE_URL; ?>/admin"> Panel</a></li>
				<li><a href="<?php echo BASE_URL; ?>/cards"> Kartlar</a></li>
				<li><a href="<?php echo BASE_URL; ?>/logout"> Çıkış Yap</a></li>
			<?php endif; ?>
		</ul>
	</nav>
</header>

<div class="row gutters mt-1">
	<div class="col col-2"></div>
	<div class="col col-8">
		<header class="header hide-sm">
			<section>
				<div class="brand">

					<a href="<?php echo BASE_URL; ?>/blog">Read Cards.</a>

				</div>
			</section>
			<nav class="navigation"><ul>
				<li><a href="<?php echo BASE_URL; ?>">Anasayfa</a></li>
				<!--<li><a href="#" class="selected" data-filter="*" id="filter-a">Tüm Kategori</a></li>-->
				<?php  foreach($listCategory as $category): ?>
					<li><a href="#" data-filter="<?php echo $category['getCategoryID']; ?>" id="filter-a"><?php echo $category['getCategoryName']; ?></a></li>
				<?php endforeach; ?>


				<?php if(!isset($_SESSION['login'])): ?>
					<li><a href="<?php echo BASE_URL; ?>/admin">Giriş Yap -></a></li>
					<?php else: ?>
						<li><a href="<?php echo BASE_URL; ?>/admin">Panel</a></li>
						<li><a href="<?php echo BASE_URL; ?>/cards">Kartlar</a></li>
						<li><a href="<?php echo BASE_URL; ?>/logout">Çıkış Yap -></a></li>
					<?php endif; ?>

				</ul>
			</nav>
		</header>
	</div>
	<div class="col col-2"></div>
</div>

<div class="desc text-center mb-4">Copyright &#169; - 2018 Read Cards. All rights reserved. Made with love by Serkan Kuyu</div>	
<!-- Kube JS + jQuery are used for some functionality, but are not required for the basic setup -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="<?php echo BASE_URL; ?>/assets/js/kube.js"></script>
<script src="<?php echo BASE_URL; ?>/assets/js/redactor.js"></script>
<script src="<?php echo BASE_URL; ?>/assets/js/source.js"></script>
<script src="<?php echo BASE_URL; ?>/assets/js/table.js"></script>
<script type="text/javascript">
		 /*
		  |--------------------------------------------------------------------------
		  | Redactor Textarea Editor
		  |--------------------------------------------------------------------------
		  |
		  | Textarea Editor
		  | Class name or id $('.content') or $('#content')
		  | File extention : all files
		  */
		  $(function(){
		  	$('.content').redactor({
		  		plugins: ['table']
		  	});
		  });


		 /*
		  |--------------------------------------------------------------------------
		  | Redactor Textarea Editor
		  |--------------------------------------------------------------------------
		  |
		  | Textarea Editor
		  | Class name or id $('.content') or $('#content')
		  | File extention : all files
		  */

		  $('#addCategory').on('submit', function(event){

		  	event.preventDefault();
		  	var getCategoryName = $('#getCategoryName').val().trim();

		  	if(getCategoryName == ""){

		  		$("#resultCategory").html('Kategori adını girin').fadeIn("slow").delay(2000).fadeOut("slow");
		  	}else{

		  		$.ajax({

		  			url:"<?php echo BASE_URL; ?>/add.php",
		  			method:"POST",
		  			data:$('#addCategory').serialize(),
		  			success: function(data){
		  				$('#addCategory')[0].reset();
		  				$('#resultCategory').html(data).fadeIn("slow").delay(2000).fadeOut("slow");
		  			}
		  		});
		  	}
		  });

		     /*
			  |--------------------------------------------------------------------------
			  | Login Form Connect
			  |--------------------------------------------------------------------------
			  |
			  | Search button between notes and users
			  | Users can search through the notes between the users and the notes written by the users
			  | #sonuc <div id="sonuc"></div>
			  */

			  $('#loginForm').on("submit", function(event){
			  	event.preventDefault();
			  	var getUsername = $('#getUsername').val().trim();
			  	var getPassword = $('#getPassword').val().trim();

			  	if(getUsername == ""){
			  		$("#resultLogin").html('<div class="message-post">Kullanıcı adınızı girin</div>').fadeIn("slow").delay(2000).fadeOut("slow");

			  	}else if(getPassword == ""){

			  		$("#resultLogin").html('<div class="message-post">Şifrenizi girin</div>').fadeIn("slow").delay(2000).fadeOut("slow");

			  	}else if(getPassword.length < 6){
			  		$("#resultLogin").html('<div class="message-post">Şifren en az 6 karakterli olmalı</div>').fadeIn("slow").delay(2000).fadeOut("slow");
			  	}else{

			  		$.ajax({

			  			url:"<?php echo BASE_URL; ?>/login",
			  			method: "POST",
			  			data:$('#loginForm').serialize(),
			  			success:function(data){

			  				$('#resultLogin').html(data).fadeIn("slow").delay(2000).fadeOut("slow");
			  			}
			  		});
			  	}
			  });



		     /*
			  |--------------------------------------------------------------------------
			  | Category Filters
			  |--------------------------------------------------------------------------
			  |
			  */

			  $(document).ready(function(){
						  	$('a#filter-a').click(function(){
			       //hide all works by default 
			       $(".work-one").addClass('filter-hide');
			       //show slected works based on the menu clicked
			       $(".work-one[data-filter='"+$(this).attr('data-filter')+"']").removeClass("filter-hide");
			       //remove selected class to the link      
			       $('a#filter-a').removeClass('selected');
			       //add selected class to the active link
			       $(this).addClass('selected');
			       return false;
			   });
			      //show all works for "all" menu
			      $('a[data-filter="*"]').click(function(event) {    
			      	$(".work-one").removeClass('filter-hide');
			      	return false;
			      });
			  });


</script>
</body>
</html>
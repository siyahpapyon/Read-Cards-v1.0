<!DOCTYPE html>
<html>
<head>
	<title>Read Card.</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Kube CSS -->
	<link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/kube.css">
	<link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/small.css">
	<link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/redactor.css">

</head>
<body>
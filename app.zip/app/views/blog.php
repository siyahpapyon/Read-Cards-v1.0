<?php  require_once VIEW_ROOT.'/theme/header.php'; ?>
<?php  require_once VIEW_ROOT.'/theme/navbar.php'; ?>

<div class="row gutters mt-2 p-2">
	<div class="col col-2"></div>
	<div class="col col-8 mb-3">
		<?php  if($listBlog['getBlogTitle'] != ""): ?>
			<div class="p-3">
				<h2><strong><?php echo e($listBlog['getBlogTitle']); ?></strong></h2>
				<p class="big"><?php echo strip_tags(substr($listBlog['getBlogContent'],0,450)); ?>...</p>
			</div>
			<div class="row gutters">
				<div class="col col-4">
					<div class="img-container">
						<img src="<?php echo BASE_URL; ?>/<?php echo $listBlog['getBlogImages']; ?>">
						<p class="topleft-d"><?php echo $listBlog['getCategoryName']; ?></p>
						<h3 class="topleft"><?php echo e($listBlog['getBlogTitle']); ?></h3>
						<p class="topleft-p"><?php echo strip_tags(substr($listBlog['getBlogContent'],0,119)); ?>...</p>
					</div>
					<div class="desc"><?php echo $listBlog['getBlogImagesAbout']; ?> 
					<?php if(isset($_SESSION['login'])): ?>
						<a href="<?php echo BASE_URL; ?>/e/<?php echo $listBlog['getBlogID']; ?>">Düzenle -></a>
					<?php endif; ?>
				</div>

			</div>
			<div class="col col-8">
				<?php echo $listBlog['getBlogContent']; ?>
				<div class="mt-3 mb-3">
					<h4><span><strong>Okunma <sup><?php echo $listBlog['hit']; ?></sup></strong></span> -> <?php echo $listBlog['hit']; ?></h4>
				</div>

			</div>
		</div>
		<?php else: ?>
			<?php  header('Location:'.BASE_URL.''); ?>
		<?php endif; ?>

	</div>
	<div class="col col-2"></div>
</div>   

<?php require_once VIEW_ROOT.'/theme/footer.php'; ?>
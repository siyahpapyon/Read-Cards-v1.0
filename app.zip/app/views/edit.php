<?php  require_once VIEW_ROOT.'/theme/header.php'; ?>
<?php  require_once VIEW_ROOT.'/theme/navbar.php'; ?>
<?php 
/* Eğer giriş yapılmamışsa URL olarak index sayfasına yönlendiriliyor. */
if(!isset($_SESSION["login"])):
	header('Location:'.BASE_URL.'/admin');?>
	<?php else: ?>
		<div class="row gutters mt-2 p-2">
			<div class="col col-2"></div>
			<div class="col col-8 mb-3">
				<?php  if($card['getBlogTitle'] != ""): ?>
					<div class="row gutters">
						<div class="col col-8 p-2" style="border-right: 1px solid #F2F3F4;">
							<div class="p-1 mb-4">
								<h3><strong>Okuma Kartını Düzenle.</strong></h3>
								<p class="lead">Hoşgeldin <?php echo $_SESSION['getUserFullname']; ?>,<br>Fikir ve düşüncelerinle özgün okuma kartları oluştur.</p>
							</div>

							<form method="post" action="<?php echo BASE_URL; ?>/e/<?php echo $card['getBlogID']; ?>" class="form" enctype="multipart/form-data">
								<div class="row gutters">
									<div class="col col-8">
										<div class="form-item">
											<label><h5><strong>-> Başlık</strong></h5></label>
											<input type="text" name="getBlogTitle" style="border:none;" value="<?php echo $card['getBlogTitle']; ?>">
										</div>
									</div>
									<div class="col col-4">
										<div class="form-item">
											<label><h5><strong>-> Kategori Seç</strong></h5></label>
											<?php  foreach($listCategory as $category): ?>
												<label class="radio"><input type="radio" name="getBlogCategory" value="<?php echo $category['getCategoryID']; ?>" <?php if($card['getBlogCategory'] == $category['getCategoryID']){echo 'checked';} ?>> <?php echo $category['getCategoryName']; ?></label>
											<?php endforeach; ?>
										</div>
									</div>
								</div>

								<div class="form-item mt-5 mb-5">
									<label><h5><strong>-> Yazının İçeriği</strong></h5></label>
									<textarea rows="6" class="content" name="getBlogContent" placeholder="Tüm içeriği bu alana girerek yazını tamamlayabilirsin"><?php echo $card['getBlogContent']; ?></textarea>
								</div>			    
								<div class="form-item mt-5 mb-5">
									<label><h5><strong>-> Resim</strong></h5></label>
									<input type="file" name="getBlogImages" disabled>
									<div class="desc">Şimdlik resim güncelleyemezsiniz.</div>
								</div>
								<div class="form-item mt-5 mb-5">
									<label><h5><strong>-> Resim Kaynak Açıklaması</strong></h5></label>
									<input type="text" name="getBlogImagesAbout" style="border:none;" placeholder="Kaynak hakkında..." value="<?php echo $card['getBlogImagesAbout']; ?>">
									<div class="desc">Kullandığın görselin kaynağını url olarak bir metin ile ifade et</div>
								</div>			    

								<div class="form-item">
									<input type="hidden" name="getBlogCreate">
									<input type="hidden" name="getBlogID" value="<?php  echo $card['getBlogID']; ?>">

									<button type="submit" class="small button">Değişiklikleri Güncelle</button>
								</div>

							</form>
						</div>
						<div class="col col-4 p-2">
							<div class="img-container">
								<img src="<?php echo BASE_URL; ?>/<?php echo $card['getBlogImages']; ?>">
								<p class="topleft-d"><?php echo $card['getCategoryName']; ?> </p>
								<h3 class="topleft"><?php echo $card['getBlogTitle']; ?></h3>
								<p class="topleft-p"><?php echo strip_tags(substr($card['getBlogContent'],0,119)); ?>...</p>
								<a href="<?php echo BASE_URL; ?>/b/<?php echo $card['getBlogID']; ?>" class="small button topleft-b">Şimdi Oku -> <?php echo $card['hit']; ?> kez okundu</a>
							</div>
							<div class="desc mb-4"><?php echo $card['getBlogImagesAbout']; ?> </div>         		

						</div>
					</div>
					<?php else: ?>
						<?php  header('Location:'.BASE_URL.'/404'); ?>
					<?php endif; ?>

				</div>
				<div class="col col-2"></div>
			</div>   
		<?php  endif; ?>
		<?php require_once VIEW_ROOT.'/theme/footer.php'; ?>
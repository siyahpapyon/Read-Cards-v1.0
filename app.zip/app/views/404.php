<?php  require_once VIEW_ROOT.'/theme/header.php'; ?>
<?php  require_once VIEW_ROOT.'/theme/navbar.php'; ?>
<div class="row mt-5">
	<div class="col col-4"></div>
	<div class="col col-4 mt-5 mb-5 p-2 text-center">
		<h5 class="ml-2 mt-1"><a href=""><strong>Read Card <sup>404 Error</sup></strong></a></h5>
		<h3><strong>Aradığın Sayfayı Bulamadık!</strong></h3>
		<p>Aradığın sayfayı bulamadıysan eğer anasayfa'ya geri dönebilirsin.</p>
		<a href="<?php echo BASE_URL; ?>" class="button small">Anasayfa'ya Dön</a>
	</div>
	<div class="col col-4"></div>
</div>


<?php require_once VIEW_ROOT.'/theme/footer.php'; ?>
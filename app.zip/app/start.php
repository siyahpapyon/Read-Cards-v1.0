<?php

/*
 |--------------------------------------
 | Dosyaları ve Uzantıları Ayarlıyoruz
 |--------------------------------------
 | VIEW_ROOT : views klasörünün içerisine erişmek için kullanılır
 | APP_ROOT  : app klasörüne ulaşmayı sağlar.
 | INIT_SET  : 'Display_error', 'On';
 | BASE_URL  : Url uzantısını belirliyoruz 
 */

 ini_set('display_errors', 'On');
 define('APP_ROOT', __DIR__);
 define('VIEW_ROOT', APP_ROOT.'/views');
 define('BASE_URL', 'http://siyahpapyon.com/blog');


/*
 |--------------------------------------
 | Mysql Bağlantısı
 |--------------------------------------
 | Mysql bağlantısını kuruyoruz.
 | 
 */

 try{
   
   $db = new PDO('mysql:host=localhost:3306;dbname=bwmsiyah_papyon_zeyn','bwmsiyah_30SZof', 'SYEss13579.??');

 }catch(PDOException $e){
   
   echo $e->getMessage();
 }


/*
 |--------------------------------------
 | Fonksiyon dosyasını dahil ediyoruz
 |--------------------------------------
 */
 
 require_once 'function.php';

